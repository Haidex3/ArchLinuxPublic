# HathemeFox – Source Code

This add-on is written in TypeScript and compiled to JavaScript.

## Build Requirements

- Linux, macOS, or Windows
- Node.js >= 18
- npm >= 9

## Build Instructions

1. Install dependencies:

   ```bash
   npm install
